<?php

use App\Http\Controllers\tugasakhirController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
Route::get('/login', function () {
    return view('login');
})->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
Route::get('/home', [tugasakhirController::class, 'showHome']);
Route::get('/register', [tugasakhirController::class, 'showRegister']); 
Route::get('/barang', [tugasakhirController::class, 'showBarang'])->name('barang');
Route::get('/keranjang', [tugasakhirController::class, 'showKeranjang'])->name('keranjang');
Route::get('/keranjang/pembayaran', [tugasakhirController::class,'showPembayaran'])->name('pembayaran');
Route::get('/keranjang/pembayaran/hasil', [tugasakhirController::class,'showHasil'])->name('hasilpembayaran');
Route::get('/admin', [tugasakhirController::class,'showHomeAdmin'])->name('adminhome');
Route::get('/admin/barang', [tugasakhirController::class,'showBarangAdmin'])->name('barangadmin');
Route::get('/admin/tambahbarang', [tugasakhirController::class,'TambahBarangAdmin'])->name('tambahbarang');
Route::get('/admin/editbarang', [tugasakhirController::class,'EditBarangAdmin'])->name('editbarang');
Route::get('/admin/riwayat', [tugasakhirController::class,'RiwayatTransaksi'])->name('riwayat');